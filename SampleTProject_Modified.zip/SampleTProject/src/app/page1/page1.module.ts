import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { MaterialModule } from '.././material/material.module';
import { AppRoutingModule } from '.././app-routing.module';
import { PageCComponent } from './page-c/page-c.component';

@NgModule({
  declarations: [PageCComponent],
  imports: [
    CommonModule,
    BrowserModule,
    MaterialModule,
    AppRoutingModule
  ],
  exports: [
    PageCComponent,
  ],

})
export class Page1Module { }
