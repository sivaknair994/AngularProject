import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageCComponent } from './Page1/page-c/page-c.component';
import { HomeComponent } from './home/home/home.component';
import { AdminCComponent } from './admin/admin-c/admin-c.component';
import { ExistingProductsComponent } from './admin/existing-products/existing-products.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'product1', component: PageCComponent },
  { path: 'admin', component: AdminCComponent },
  { path: 'prodList', component: ExistingProductsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
