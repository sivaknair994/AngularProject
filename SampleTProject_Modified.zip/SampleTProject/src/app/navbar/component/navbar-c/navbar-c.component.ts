import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navbar-c',
  templateUrl: './navbar-c.component.html',
  styleUrls: ['./navbar-c.component.css']
})
export class NavbarCComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
