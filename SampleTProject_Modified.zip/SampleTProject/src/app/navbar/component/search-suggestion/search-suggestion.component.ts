import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'search-suggestion',
  templateUrl: './search-suggestion.component.html',
  styleUrls: ['./search-suggestion.component.css']
})
export class SearchSuggestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
