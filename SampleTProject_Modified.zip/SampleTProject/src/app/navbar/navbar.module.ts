import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '.././material/material.module';
import { NavbarCComponent } from './component/navbar-c/navbar-c.component';
import { AppRoutingModule } from '.././app-routing.module';
import { SearchSuggestionComponent } from './component/search-suggestion/search-suggestion.component';



@NgModule({
  declarations: [NavbarCComponent, 
                SearchSuggestionComponent
              ],
  imports: [
    CommonModule,
    MaterialModule,
    AppRoutingModule
  ],
  exports: [
    NavbarCComponent,
    SearchSuggestionComponent
  ]
})
export class NavbarModule { }
