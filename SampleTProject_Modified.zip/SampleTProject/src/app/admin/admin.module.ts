import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminCComponent } from './admin-c/admin-c.component';
import { MaterialModule } from '.././material/material.module';
import { AppRoutingModule } from '.././app-routing.module';
import { ExistingProductsComponent } from './existing-products/existing-products.component';

@NgModule({
  declarations: [AdminCComponent, 
    ExistingProductsComponent],
  imports: [
    ReactiveFormsModule,
    CommonModule,
    MaterialModule,
    AppRoutingModule
  ],
  exports: [AdminCComponent,
    ExistingProductsComponent]
})
export class AdminModule { }
