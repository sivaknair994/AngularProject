import { Component, Inject, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';  
import {ActivatedRoute} from '@angular/router';
import { Directive, ElementRef, HostListener } from '@angular/core';
import { AdminService } from './../admin.service';
import { PRODUCT_DATA } from '.././existing-products/existing-products.component';

export let productData = PRODUCT_DATA;

@Component({
  selector: 'admin-c',
  templateUrl: './admin-c.component.html',
  styleUrls: ['./admin-c.component.css']
})
export class AdminCComponent {

  newProductForm = new FormGroup({
    prod_id: new FormControl(''),
    prod_name: new FormControl(''),
    prod_type: new FormControl(''),
    prod_brand: new FormControl(''),
    prod_model: new FormControl(''),
    prod_price: new FormControl(''),
    prod_stock: new FormControl(''),
  });

  private route: ActivatedRoute;

  constructor(/**private adminService: AdminService*/) { }

  onSubmit() {    

    PRODUCT_DATA.push(this.newProductForm.value);
    productData = PRODUCT_DATA;
    //console.log(productData);
    //console.log(this.newProductForm.value);

    if(confirm('Product has been added, Please click Existing Button to View List')){
      this.newProductForm.reset();  
    }
    //this.adminService.addNewProduct(this.newProductForm.value);
  }

}
