import { Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute} from '@angular/router';
import { productData } from '.././admin-c/admin-c.component';

export interface ProductList {
  prod_name: string;
  prod_type: string;
  prod_brand: string;
  prod_model: string;
  prod_price: string;
  prod_stock: string;
  prod_id: number;
}

export const PRODUCT_DATA: ProductList[] = [
  {prod_id: 1, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 2, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 3, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 4, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 5, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 6, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 7, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 8, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 9, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
  {prod_id: 10, prod_name: 'Samsung Tablet', prod_type: 'Tablet', prod_brand: 'Samsung', prod_model: 'TAB A', prod_price: '9999', prod_stock: '1000'},
];


@Component({
  selector: 'app-existing-products',
  templateUrl: './existing-products.component.html',
  styleUrls: ['./existing-products.component.css']
})
export class ExistingProductsComponent {

  private route: ActivatedRoute;
  
  displayedColumns: string[] = ['prod_id', 'prod_name', 'prod_type', 'prod_brand', 'prod_model', 'prod_price', 'prod_stock', 'delete'];
  dataSource = new MatTableDataSource(productData);
  

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ngOnInit() {
    this.dataSource.sort = this.sort;
  }

  onItemDeleted(id){ 

    if(confirm('Are you Sure you want to detele Item?')){
      var index = PRODUCT_DATA.findIndex(x => x.prod_id === id);
      PRODUCT_DATA.splice(index, 1); 
      console.log(PRODUCT_DATA);
      this.dataSource = new MatTableDataSource(PRODUCT_DATA);   
    }

  }

}
