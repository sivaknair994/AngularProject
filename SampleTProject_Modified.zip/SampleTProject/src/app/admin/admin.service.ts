import { Injectable } from '@angular/core';
import {HttpClientModule, HttpClient, HttpRequest, HttpResponse, HttpEventType} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AdminService {

  data: [];
  prodId: string;
  prodName: string;
  pName: string;
  pType: string;
  pBrand: string;
  pModel: string;
  pPrice: string;
  pStock: string;
  responseBody: string[];

  constructor(private http: HttpClient,) { }

  addNewProduct(data){

    var formData = new FormData();
    Array.from(data).forEach(f => formData.append('prod_name', this.pName));
    Array.from(data).forEach(f => formData.append('prod_type', this.pType));
    Array.from(data).forEach(f => formData.append('prod_brand', this.pBrand));
    Array.from(data).forEach(f => formData.append('prod_model', this.pModel));
    Array.from(data).forEach(f => formData.append('prod_Price', this.pPrice));
    Array.from(data).forEach(f => formData.append('prod_Stock', this.pStock));

    this.http.post('www.example.com/check', formData, {reportProgress: true, observe: 'events'})
        .subscribe(event => {
            let response = JSON.stringify(event);
            let responseJson = JSON.parse(response);
            let responseBody1 = responseJson;

            let prod_Id = responseJson.prodId;
            let prod_Name = responseJson.prodName;

            this.responseBody = responseBody1;
            this.prodId = prod_Id;
            this.prodName = prod_Name;
    });

  }
}
